package com.example.bookmybatis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMybatisApplication.class, args);
	}

}
